import time


while True:
    print "Hello World!"
    time.sleep(60)
